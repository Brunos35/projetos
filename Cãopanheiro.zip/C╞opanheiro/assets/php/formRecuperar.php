<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Senha</title>

    <link rel="stylesheet" href="../css/login.css">
    <style>
        .container {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .formbox {
            width: 300px;
            height: 250px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); 
            border-radius: 10px; 
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .formbox h1 {
            margin-bottom: 20px; 
        }

        form{
            width:100%;
        }

        .inputbox {
            margin: 0 0 20px 0;
            width: 100%;

        }

        .inputbox input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;         
        }

        .inputbox label {
            display: block;
            margin-top: 10px;

        }

    </style>
</head>
<body>
    <div class="container">
        <div class="formbox" id="box">
            <h1>Recuperar Senha</h1>
            <form action="process_recovery.php" autocomplete="on" method="post">
                <div class="inputbox">
                    <input type="email" name="email" id="email" required autocomplete="email">
                    <label for="email">E-mail</label>
                </div>
                <button class="env">Enviar</button>
            </form>
        </div>
    </div>
</body>
</html>
