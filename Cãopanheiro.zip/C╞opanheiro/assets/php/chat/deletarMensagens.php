<?php
include 'db.php';
checkAuth();

function sanitizeInput($data) {
    return htmlspecialchars(strip_tags($data));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idChat = sanitizeInput($_POST['idChat']);

    if (!empty($idChat) && is_numeric($idChat)) {
        $sql = "DELETE FROM chat WHERE idChat = '$idChat'";

        if ($conn->query($sql) === TRUE) {
            echo "Chat deleted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Invalid input.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Chat</title>
</head>
<body>
    <form method="post" action="">
        <label for="idChat">Chat ID:</label>
        <input type="text" id="idChat" name="idChat"><br>
        <input type="submit" value="Delete Chat">
    </form>
</body>
</html>
