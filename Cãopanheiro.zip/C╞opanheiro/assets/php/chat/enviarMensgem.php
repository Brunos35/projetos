<?php
include 'db.php';
checkAuth();

function sanitizeInput($data) {
    return htmlspecialchars(strip_tags($data));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idChat = sanitizeInput($_POST['idChat']);
    $remetente = sanitizeInput($_POST['remetente']);
    $conteudo = sanitizeInput($_POST['conteudo']);

    if (!empty($idChat) && !empty($remetente) && !empty($conteudo) && is_numeric($idChat) && is_numeric($remetente)) {
        $sql = "INSERT INTO mensagem (idChat, remetente, conteudo, dataEnvio) VALUES ('$idChat', '$remetente', '$conteudo', NOW())";

        if ($conn->query($sql) === TRUE) {
            echo "Message sent successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Invalid input.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Send Message</title>
</head>
<body>
    <form method="post" action="">
        <label for="idChat">Chat ID:</label>
        <input type="text" id="idChat" name="idChat"><br>
        <label for="remetente">Remetente ID:</label>
        <input type="text" id="remetente" name="remetente"><br>
        <label for="conteudo">Conteudo:</label>
        <textarea id="conteudo" name="conteudo"></textarea><br>
        <input type="submit" value="Send Message">
    </form>
</body>
</html>
