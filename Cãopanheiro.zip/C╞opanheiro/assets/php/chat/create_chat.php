<?php
include 'db.php';
checkAuth();

function sanitizeInput($data) {
    return htmlspecialchars(strip_tags($data));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario1 = sanitizeInput($_POST['usuario1']);
    $usuario2 = sanitizeInput($_POST['usuario2']);

    if (!empty($usuario1) && !empty($usuario2) && is_numeric($usuario1) && is_numeric($usuario2)) {
        $sql = "INSERT INTO chat (usuario1, usuario2) VALUES ('$usuario1', '$usuario2')";

        if ($conn->query($sql) === TRUE) {
            echo "Chat created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Invalid input.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Chat</title>
</head>
<body>
    <form method="post" action="">
        <label for="usuario1">Usuario 1 ID:</label>
        <input type="text" id="usuario1" name="usuario1"><br>
        <label for="usuario2">Usuario 2 ID:</label>
        <input type="text" id="usuario2" name="usuario2"><br>
        <input type="submit" value="Create Chat">
    </form>
</body>
</html>
